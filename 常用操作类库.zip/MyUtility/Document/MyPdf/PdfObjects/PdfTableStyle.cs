using System;
using System.Drawing;


namespace SmartPdf.PdfObjects
{
	public class PdfTableStyle
	{
		internal Color backGroundColor,alternateBackgroundColor,foreGroundColor
			,headerBackGroundColor,headerForegroundColor;
		public PdfTableStyle()
		{
			
		}
	}
}
