namespace las.foundation.SmartExcel
{
    using System;

    public enum CellFont
    {
        Font0 = 0,
        Font1 = 0x40,
        Font2 = 0x80,
        Font3 = 0xc0
    }
}
