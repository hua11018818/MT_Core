namespace las.foundation.SmartExcel
{
    using System;

    public enum FontFormatting
    {
        Bold = 1,
        Italic = 2,
        NoFormat = 0,
        Strikeout = 8,
        Underline = 4
    }
}
