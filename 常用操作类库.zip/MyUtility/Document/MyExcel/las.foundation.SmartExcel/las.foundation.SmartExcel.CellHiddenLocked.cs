namespace las.foundation.SmartExcel
{
    using System;

    public enum CellHiddenLocked
    {
        Hidden = 0x80,
        Locked = 0x40,
        Normal = 0
    }
}
