namespace las.foundation.SmartExcel
{
    using System;

    public enum ValueTypes
    {
        Integer,
        Number,
        Text
    }
}
