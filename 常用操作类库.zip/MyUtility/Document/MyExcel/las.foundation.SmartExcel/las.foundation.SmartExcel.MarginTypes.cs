namespace las.foundation.SmartExcel
{
    using System;

    public enum MarginTypes
    {
        BottomMargin = 0x29,
        LeftMargin = 0x26,
        RightMargin = 0x27,
        TopMargin = 40
    }
}
